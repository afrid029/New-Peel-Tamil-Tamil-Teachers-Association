<?php

/**
 * Setup / Install Script
 * Run this once to create database tables and seed the super admin.
 * DELETE THIS FILE after setup is complete for security.
 *
 * Usage: navigate to setup.php in your browser
 */
require_once __DIR__ . '/includes/config.php';

$status  = [];
$success = true;

try {
    // Connect without database first
    $pdo = new PDO('mysql:host=' . DB_HOST . ';charset=' . DB_CHARSET, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    // Create database
    $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $pdo->exec('USE `' . DB_NAME . '`');
    $status[] = ['OK', 'Database created / selected: ' . DB_NAME];

    // Read and run schema
    $sqlFile = __DIR__ . '/sql/schema.sql';
    $sql = file_get_contents($sqlFile);

    // Strip all SQL comment lines first (-- …)
    $sql = preg_replace('/^\s*--.*$/m', '', $sql);

    // Remove CREATE DATABASE / USE / INSERT seed (may span multiple lines due to formatters)
    $sql = preg_replace('/CREATE\s+DATABASE\s+.*?;/si', '', $sql);
    $sql = preg_replace('/USE\s+\w+\s*;/si', '', $sql);
    $sql = preg_replace('/INSERT\s+INTO\s+users\s*\(.*?;/si', '', $sql);

    // Split by semicolons and execute each statement
    $statements = array_filter(array_map('trim', explode(';', $sql)));
    foreach ($statements as $stmt) {
        if ($stmt === '') continue;
        try {
            $pdo->exec($stmt);
        } catch (PDOException $e) {
            // Ignore "already exists" errors
            if (strpos($e->getMessage(), 'already exists') === false && strpos($e->getMessage(), 'Duplicate') === false) {
                $status[] = ['WARN', 'SQL: ' . substr($stmt, 0, 60) . '... — ' . $e->getMessage()];
            }
        }
    }
    $status[] = ['OK', 'All tables created successfully.'];

    // Seed super admin with proper hash
    $adminEmail = 'info@nptta.ca';
    $adminPw    = '$Toronto#2024!';
    $hash       = password_hash($adminPw, PASSWORD_BCRYPT, ['cost' => 12]);

    $check = $pdo->prepare('SELECT id FROM users WHERE email = ?');
    $check->execute([$adminEmail]);
    if (!$check->fetch()) {
        $stmt = $pdo->prepare(
            'INSERT INTO users (id, first_name, last_name, email, password, role, first_login)
             VALUES (1, ?, ?, ?, ?, ?, 0)'
        );
        $stmt->execute(['Super', 'Admin', $adminEmail, $hash, 'super_admin']);
        $status[] = ['OK', "Super admin created — Email: {$adminEmail} / Password: {$adminPw}"];
    } else {
        $status[] = ['INFO', 'Super admin already exists.'];
    }

    // Create upload directories
    $dirs = [UPLOAD_DIR, UPLOAD_DIR . '/posters'];
    foreach ($dirs as $dir) {
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
            $status[] = ['OK', 'Created directory: ' . $dir];
        }
    }
} catch (PDOException $e) {
    $success = false;
    $status[] = ['ERROR', 'Database error: ' . $e->getMessage()];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup – NPTTA</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="assets/css/custom.css">
</head>

<body class="flex items-center justify-center min-h-screen" style="background:var(--bg);">
    <div class="w-full max-w-xl px-4">
        <div class="card" style="padding:36px;">
            <h1 class="text-xl font-bold mb-6" style="color:var(--primary);">NPTTA – Setup</h1>

            <?php foreach ($status as $s): ?>
                <div class="flex items-start gap-3 mb-3">
                    <?php if ($s[0] === 'OK'): ?>
                        <span class="text-green-600 font-bold text-sm mt-0.5">✓</span>
                    <?php elseif ($s[0] === 'ERROR'): ?>
                        <span class="text-red-600 font-bold text-sm mt-0.5">✕</span>
                    <?php else: ?>
                        <span class="text-yellow-600 font-bold text-sm mt-0.5">●</span>
                    <?php endif; ?>
                    <p class="text-sm"><?= htmlspecialchars($s[1]) ?></p>
                </div>
            <?php endforeach; ?>

            <?php if ($success): ?>
                <div class="mt-6 p-4 rounded-lg" style="background:var(--accent);">
                    <p class="text-sm font-semibold" style="color:var(--primary);">Setup Complete!</p>
                    <p class="text-sm mt-1"><strong>Super Admin Login:</strong></p>
                    <p class="text-sm">Email: <code>admin@nptta.ca</code></p>
                    <p class="text-sm">Password: <code>Admin@123</code></p>
                    <p class="text-xs mt-3 text-red-600 font-semibold">⚠ DELETE this setup.php file immediately for security!</p>
                </div>
                <a href="login.php" class="btn-primary inline-block mt-4">Go to Login</a>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>